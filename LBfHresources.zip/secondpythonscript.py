#! /usr/bin/python3

HackersAriseStringVariable = "Hackers-Arise is the Best Place to Learn Hacking";

HackersAriseIntegerVariable = 12

HackersAriseFloatingPointVariable = 3.1415

HackersAriseList = [1,2,3,4,5,6]

HackersAriseDictionary = {'name' : 'OccupytheWeb', 'value' : 27}

print (HackersAriseStringVariable) 

print (HackersAriseIntegerVariable) 

print (HackersAriseFloatingPointVariable) 

print (HackersAriseList[3])



