#! /usr/bin/python3

name="OccupytheWeb"

print ("Greetings to "+name+" from Hackers-Arise. The Best Place to Learn Hacking!")